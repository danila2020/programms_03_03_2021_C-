#include <QCoreApplication> // подключение библиотеки в QTcreator чтобы мы могли с ней работать
#include <iostream> // это ввод и вывод
#include <cmath>

using namespace std; // чтобы мы могли исполльзовать cout и cin, то есть пространство имен


// Класс геометрических фигур
class GeometricFigure
{
protected: // это чтобы записать новые переменные
    int count; // Количество сторон
    int lines[10]; // Сами стороны многоугольника, максимум можем ввести 10 сторон
public: // публичный уровень доступа
    // Конструктор класса, передаем желаемое количество сторон и сами стороны.
    GeometricFigure(int count, int *lines) //  int* lines мы ожидаем массив с целочисленными элементами
    {
        this->count = count; // мы конкретную будем изменять
        for (int i = 0; i < count; i++)
            this->lines[i] = lines[i]; // конкретной переменнной присваиваем значение
    }
    ~GeometricFigure() {} // ~ - это деструктор, то есть место класса которое вызывается всегда перед завершением работы пррограммы

    // Метод нахождения перимеетра
    int get_perimetr() // это функция
    {
        int perimetr = 0;
        // Периметр - сумма длин всех сторон многоугольника
        for (int i = 0; i < count; i++)
            perimetr += lines[i];

        return perimetr; // чтобы мы могли вернуть значение для пользователя
    }

    // Метод нахождения площади
    double get_area()
    {
        double area = 0;
        // Здесь нужно посчитать площадь многоугольника по сторонам (посмотреть в интернете)

        return area; // чтобы мы могли вернуть значение для пользователя
    }

    // Вывод информации о фигуре
    void show_info()
    {
        cout << "Figure with lines: "; // объявление что фигура со следующими сторонами
        for (int i = 0; i < count; i++)
            cout << " " << lines[i]; // выводит на экран сами значения сторон
        cout << endl;

        cout << "Count of lines: " << count << endl;
        cout << "Perimetr: " << get_perimetr() << endl;
        cout << "Area: " << get_area() << endl;
    }
};


// Класс треугольника, наследуется от класса геометрических фигур.
class Triangle : public GeometricFigure
{
public:
    // По умолчанию в треугольнике 3 стороны
    Triangle(int *lines) : GeometricFigure(3, lines) {};
    ~Triangle() {} // деструктор говорим что он есть, то есть вызывается перед завершением программы (перед удалением объекта)
};

// Класс равнобедренного треугольника, наследуется от класса треугольника
class IsoscelesTriangle : public Triangle
{
public:
    IsoscelesTriangle(int *lines) : Triangle(lines) {}; // конструуктор равнобедренного треугольника
    ~IsoscelesTriangle() {}

    // Добавлен метод опредления высоты равнобедренного треугольника
    double get_h()
    {
        double p = get_perimetr() / 2.0;
        double h = 2 * sqrt(p * (p - lines[0]) * (p - lines[1]) * (p - lines[2]));
        h /= lines[2];

        return h;
    }

};

// Класс прямоугольника, наследуется от класса геометрических фигур
class Rectangle : public GeometricFigure
{
public:
    Rectangle(int *lines) : GeometricFigure(4, lines) {};
    ~Rectangle() {}


    // Добавлен метод нахождения диагонали многоугольника
    // как если бы искали гипотенузу прямоугольного треугольника
    double get_d()
    {
        double d = sqrt(lines[0] *lines[0] + lines[2] * lines[2]);
        return d;
    }
};


// Класс квадрата, наследуется от класса прямоугольника
class Square : public Rectangle
{
public:
    Square(int *lines) : Rectangle(lines) {};
    ~Square() {}
};


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Тестирование равнобедренного треугольника
    int lines_01[3] = {5, 5, 3};
    IsoscelesTriangle figure_01(lines_01); // IsoscelesTriangle - класс равнобедренного треугольника
    figure_01.show_info();
    cout << figure_01.get_h() << endl;

    // Тестирование прямоугольника
    int lines_02[4] = {5, 5, 3, 3};
    Rectangle figure_02(lines_02);
    figure_02.show_info(); // вывод на экран
    cout << figure_02.get_d() << endl;

    return a.exec();
}
