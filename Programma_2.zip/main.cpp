#include <QCoreApplication>
#include <iostream>
using namespace std;
// print - это метод класса который мы самостоятельно описали


class Square
{
// По условию квадрат определяется длиной стороны (стороны достаточно одной, так как в квадрате все стороны равны)
// и координатами центра
private:
    // Длина стороны
    double line;
    // Координаты центра
    double x;
    double y;
public:
    // Конструктор по умолчанию.
    // По умолчанию задаем стороны квадрата, равными единице, а его центр находится в точке с координатами (0, 0)
    Square()
    {
        line = 1;
        x = 0;
        y = 0;
    }

    // Конструктор в котором мы задаем самостоятельно длину стороны
    Square(int line)
    {
        this->line = line;
        x = 0;
        y = 0;
    }

    // Конструктор, задаем длины сторон и расположение
    Square(double line, double x, double y)
    {
        this->line = line;
        this->x = x;
        this->y = y;
    }

    // Конструктор копирования - конструктор который копирует другой объект
    Square(Square &s)
    {
        this->line = s.line;
        this->x = s.x;
        this->y = s.y;
    }

    // Вывод информации о квадрате
    void print() // cout это встроенный в С++ способ вывода информации на экран
    {
        cout << "Information:" << endl;
        cout << "\tline - " << line << endl;
        cout << "\t(x, y) - " << x << " " << y << endl;
        cout << "\tarea - " << area() << endl;
    }

    // Перегрузка оператора умнжения. По условию врианта, при умножении объета на число, изменяются его
    // координаты центра.
    Square operator*(double number)
    {
        Square result;

        result.line = line;
        result.x = x * number;
        result.y = y * number;

        return result;
    }

    // Вычисление площади квадрата
    double area()
    {
        return line * line;
    }
};


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Square s_1(2, 1, 1); // s_1 - это переменная которую объявили в main
    s_1.print();

    Square s_2 = s_1 * 5; // s_2 - это переменная которую объявили в main
    s_2.print();

    return a.exec();
}
